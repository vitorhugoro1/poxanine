# About me Widget

  This is a plugin for peoples that want, add a **widget** or **shortcode**, on sidebar or in content of posts, pages or custom post types, to shows your resume informations, but doesn't search a complicate plugin for resolve it.

#### Requeriments
> Wordpress - 4.0 > higher

#### Developer
> Vitor Hugo Rodrigues Merencio - [Github](https://github.com/vitorhugoro1/)
